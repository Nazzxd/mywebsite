import React from "react";
import { useTranslation } from "react-i18next";

const Header = () => {
  const { t, i18n } = useTranslation();

  const changeLanguage = (lng) => i18n.changeLanguage(lng);

  return (
    <header className="relative w-full h-screen text-white">
    
      <div className="flex justify-center md:justify-end">
        <img
          src="/img/photo1.jpg"
          alt={t("header.title")}
          className="absolute w-400 h-250 mr--10 brightness-50"
          draggable="false"
        />
      </div>

      
      <nav className="absolute top-20 left-1/2 transform -translate-x-1/2 flex gap-20 z-10">
        <a href="#" className="text-white">{t("nav.home")}</a>
        <a href="#" className="text-white">{t("nav.about")}</a>
        <a href="#" className="text-white">{t("nav.tours")}</a>
        <a href="#" className="text-white">{t("nav.gallery")}</a>
        <a href="#" className="text-white">{t("nav.reviews")}</a>
        <a href="#" className="text-white">{t("nav.contact")}</a>
      </nav>

      
      <h1 className="absolute top-1/4 left-1/2 transform -translate-x-1/2 text-6xl font-bold z-10 text-center">
        {t("header.title")}
      </h1>

      
      <h2 className="absolute top-[45%] left-1/2 transform -translate-x-1/2 text-lg opacity-80 text-center z-10">
        {t("header.subtitle")}
      </h2>

      
      <div className="absolute top-5 right-5 flex gap-2">
        <button onClick={() => changeLanguage("en")} className="bg-white text-black px-2 rounded">EN</button>
        <button onClick={() => changeLanguage("ua")} className="bg-white text-black px-2 rounded">UA</button>
      </div>
    </header>
  );
};

export default Header;
