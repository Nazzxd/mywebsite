import Header from "./components/Header";
import SEO from "./components/SEO";

function App() {
  return (
    <>
      <SEO />
      <Header />
    </>
  );
}

export default App;
