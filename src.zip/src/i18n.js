
import i18n from "i18next";
import { initReactI18next } from "react-i18next";

const resources = {
  en: {
    translation: {
      nav: {
        home: "Home",
        about: "About Us",
        tours: "Tours",
        gallery: "Gallery",
        reviews: "Reviews",
        contact: "Contact"
      },
      header: {
        title: "Travel Time",
        subtitle: "Let's travel with us! We will start a new adventure together full of happiness and laughs"
      },
      seo: {
        title: "Travel Time — Best Trips",
        description: "Travel Time - your guide to amazing vacations",
        keywords: "travel, vacations, travel time, relax"
      }
    }
  },
  ua: {
    translation: {
      nav: {
        home: "Головна",
        about: "Про нас",
        tours: "Тури",
        gallery: "Галерея",
        reviews: "Відгуки",
        contact: "Контакти"
      },
      header: {
        title: "Час для подорожей",
        subtitle: "Подорожуй з нами! Ми розпочнемо нову пригоду разом, повну щастя та сміху"
      },
      seo: {
        title: "Подорож Часу — Найкращі Подорожі",
        description: "Подорож Часу - ваш провідник до неймовірних відпусток",
        keywords: "подорожі, відпустки, подорож часу, відпочинок"
      }
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: "en",
    fallbackLng: "en",
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
